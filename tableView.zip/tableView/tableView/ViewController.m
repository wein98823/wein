//
//  ViewController.m
//  tableView
//
//  Created by ios on 2015/3/11.
//  Copyright (c) 2015年 liangjason. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *tableView1;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _tableView1.dataSource=self;
    _tableView1.delegate=self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    UITableViewCell *cell;
    //    static NSString* CellID=@"myCellID";
    cell=[tableView dequeueReusableCellWithIdentifier:@"myCell"];
    UILabel *mainLabel;
    UILabel *subLabel;
    UIImageView *imgView;
    for (UIView *view in cell.contentView.subviews) {
//        NSLog(@"lbl = %@",lbl.text);
        switch (view.tag) {
            case 1:
                mainLabel=(UILabel *)view;
                break;
            case 2:
                subLabel=(UILabel *)view;
                break;
            case 3:
                imgView=(UIImageView *)view;
                break;
            default:
                break;
        }
    }
    switch (indexPath.row) {
        case 0:
            mainLabel.text=@"AAAA";
            subLabel.text=@"111";
            imgView.image=[UIImage imageNamed:@"2.jpeg"];
            break;
        case 1:
            mainLabel.text=@"BBB";
            subLabel.text=@"222";
            imgView.image=[UIImage imageNamed:@"3.jpeg"];
            break;
        case 2:
            mainLabel.text=@"CCC";
            subLabel.text=@"333";
            imgView.image=[UIImage imageNamed:@"4.png"];
            break;
            
        default:
            break;
    }
    return cell;
}
@end
